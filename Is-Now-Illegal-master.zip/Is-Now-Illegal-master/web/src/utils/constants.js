/* eslint-disable import/prefer-default-export */

export const APP_TITLE = 'IsNowIllegal.com';
export const SUBJECT_PATTERN_ALLOW = /^[a-zA-Z0-9\s]+$/i;
export const SUBJECT_PATTERN_REJECT = /[^a-zA-Z0-9\s]/ig;
export const WORD_MAX_LEN = 10;
