import styled from 'styled-components';

export default styled.span`
  color: #333;
  font-weight: bold;
`;
