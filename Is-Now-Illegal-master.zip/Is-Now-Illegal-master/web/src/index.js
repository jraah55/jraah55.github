import React from 'react';
import ReactDOM from 'react-dom';

import App from './App';
// import App from './pages/MaintenancePage';

ReactDOM.render(<App />, document.getElementById('root'));
