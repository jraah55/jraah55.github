# Is Now Illegal!
A NERD protest against Trump's Immigration ban 🚫
Go to [IsNowIllegal.com](http://isnowillegal.com) and type what you want to make illegal!

## What's this?
A webapp that gives you the Donald J. Trump power. Pretend you are Trump for a few seconds, make something illegal, share with friends and have fun!

## Who made this?
![](https://github.com/ivanseidel.png?size=100)
Ivan Seidel ([github](https://github.com/ivanseidel))

![](https://github.com/brunolemos.png?size=100)
Bruno Lemos ([github](https://github.com/brunolemos), [twitter](https://twitter.com/brunolemos))

![](https://github.com/joaopedrovbs.png?size=100)
João Pedro ([github](https://github.com/joaopedrovbs))
