//
//  Lottie.h
//  Lottie
//
//  Created by brandon_withrow on 1/27/17.
//  Copyright © 2017 Airbnb. All rights reserved.
//

#import <UIKit/UIKit.h>

//! Project version number for Lottie.
FOUNDATION_EXPORT double LottieVersionNumber;

//! Project version string for Lottie.
FOUNDATION_EXPORT const unsigned char LottieVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <Lottie/PublicHeader.h>


