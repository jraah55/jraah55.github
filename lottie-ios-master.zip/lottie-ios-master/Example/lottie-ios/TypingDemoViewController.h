//
//  LATypingDemoViewController.h
//  LottieExamples
//
//  Created by Brandon Withrow on 1/9/17.
//  Copyright © 2017 Brandon Withrow. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface TypingDemoViewController : UIViewController

@end
