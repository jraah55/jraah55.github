module.exports = require('./lib/js/Animation');
