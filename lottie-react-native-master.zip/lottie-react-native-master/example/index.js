import { AppRegistry } from 'react-native';
import LottieAnimatedExample from './LottieAnimatedExample';

AppRegistry.registerComponent('example', () => LottieAnimatedExample);
