# Change Log

## 1.0.1 (Feb 2, 2017)

- Fix Header / Build issues with iOS on RN 0.40+

## 1.0.0 (Feb 1, 2017)

- Official Release!
