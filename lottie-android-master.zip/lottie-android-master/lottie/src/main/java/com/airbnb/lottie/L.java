package com.airbnb.lottie;

public class L {
  public static final boolean DBG = false;
}
