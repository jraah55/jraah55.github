package com.airbnb.lottie;

import android.support.test.runner.AndroidJUnitRunner;


public class TestRunner extends AndroidJUnitRunner {
}
