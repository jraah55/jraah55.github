﻿using GVFS.FunctionalTests.FileSystemRunners;
using GVFS.FunctionalTests.Should;
using GVFS.FunctionalTests.Tools;
using GVFS.Tests.Should;
using NUnit.Framework;
using System;
using System.IO;
using System.Runtime.CompilerServices;

namespace GVFS.FunctionalTests.Tests.EnlistmentPerFixture
{
    [TestFixture]
    public class GitCommandsTests : TestsWithEnlistmentPerFixture
    {
        private const string EncodingFileFolder = "FilenameEncoding";
        private const string EncodingFilename = "ريلٌأكتوبرûمارسأغسطسºٰٰۂْٗ۵ريلٌأك.txt";
        private const string ContentWhenEditingFile = "// Adding a comment to the file";
        private const string EditFilePath = @"GVFS\GVFS.Common\GVFSContext.cs";
        private const string DeleteFilePath = @"GVFS\GVFS\Program.cs";
        private const string RenameFilePathFrom = @"GVFS\GVFS.Common\Physical\FileSystem\FileProperties.cs";
        private const string RenameFilePathTo = @"GVFS\GVFS.Common\Physical\FileSystem\FileProperties2.cs";
        private const string RenameFolderPathFrom = @"GVFS\GVFS.Common\Physical\FileSystem";
        private const string RenameFolderPathTo = @"GVFS\GVFS.Common\Physical\FileSyst3m";
        private const string UnknownTestName = "Unknown";
        private FileSystemRunner fileSystem;

        public GitCommandsTests()
        {
            this.fileSystem = new SystemIORunner();
        }

        public ControlGitRepo ControlGitRepo
        {
            get; private set;
        }

        public override void CreateEnlistment()
        {
            base.CreateEnlistment();
            GitProcess.Invoke(this.Enlistment.RepoRoot, "config advice.statusUoption false");
            GitProcess.Invoke(this.Enlistment.RepoRoot, "config core.abbrev 12");

            this.ControlGitRepo = ControlGitRepo.Create();
            this.ControlGitRepo.Initialize();
        }

        public override void DeleteEnlistment()
        {
            base.DeleteEnlistment();
            this.ControlGitRepo.Delete();
        }

        [SetUp]
        public void TestSetup()
        {
            this.ValidateGitCommand("checkout " + this.ControlGitRepo.Commitish);

            this.CheckHeadCommitTree();
            this.Enlistment.RepoRoot.ShouldBeADirectory(this.fileSystem)
                .WithDeepStructure(this.ControlGitRepo.RootPath);
            this.ValidateGitCommand("status");
        }

        [TearDown]
        public void TestTearDown()
        {
            this.CheckHeadCommitTree();
            this.Enlistment.RepoRoot.ShouldBeADirectory(this.fileSystem)
                .WithDeepStructure(this.ControlGitRepo.RootPath);

            this.RunGitCommandNoProgress("reset --hard HEAD");
            this.ValidateGitCommand("clean -d -f -x");
            this.ValidateGitCommand("checkout " + this.ControlGitRepo.Commitish);

            this.CheckHeadCommitTree();
            this.Enlistment.RepoRoot.ShouldBeADirectory(this.fileSystem)
                .WithDeepStructure(this.ControlGitRepo.RootPath);
        }

        [TestCase]
        public void VerifyTestFilesExist()
        {
            // Sanity checks to ensure that the test files we expect to be in our test repo are present
            Path.Combine(this.Enlistment.RepoRoot, EncodingFileFolder, EncodingFilename).ShouldBeAFile(this.fileSystem);
            Path.Combine(this.Enlistment.RepoRoot, EditFilePath).ShouldBeAFile(this.fileSystem);
            Path.Combine(this.Enlistment.RepoRoot, DeleteFilePath).ShouldBeAFile(this.fileSystem);
            Path.Combine(this.Enlistment.RepoRoot, RenameFilePathFrom).ShouldBeAFile(this.fileSystem);
            Path.Combine(this.Enlistment.RepoRoot, RenameFolderPathFrom).ShouldBeADirectory(this.fileSystem);
        }

        [TestCase]
        public void StatusTest()
        {
            this.ValidateGitCommand("status");
        }

        [TestCase]
        public void StatusShortTest()
        {
            this.ValidateGitCommand("status -s");
        }

        [TestCase]
        public void BranchTest()
        {
            this.ValidateGitCommand("branch");
        }

        [TestCase]
        public void NewBranchTest()
        {
            this.ValidateGitCommand("branch tests/functional/NewBranchTest");
            this.ValidateGitCommand("branch");
        }

        [TestCase]
        public void DeleteBranchTest()
        {
            this.ValidateGitCommand("branch tests/functional/DeleteBranchTest");
            this.ValidateGitCommand("branch");
            this.ValidateGitCommand("branch -d tests/functional/DeleteBranchTest");
            this.ValidateGitCommand("branch");
        }

        [TestCase]
        public void RenameCurrentBranchTest()
        {
            this.ValidateGitCommand("checkout -b tests/functional/RenameBranchTest");
            this.ValidateGitCommand("branch -m tests/functional/RenameBranchTest2");
            this.ValidateGitCommand("branch");
        }

        [TestCase]
        public void UntrackedFileTest()
        {
            this.ValidateGitCommand("checkout -b tests/functional/UntrackedFileTest");
            this.CreateFile();
            this.ValidateGitCommand("status");
            this.ValidateGitCommand("add .");
            this.RunGitCommand("commit -m \"Add new file\"");
            this.ValidateGitCommand("status");
        }

        [TestCase]
        public void UntrackedEmptyFileTest()
        {
            this.ValidateGitCommand("checkout -b tests/functional/UntrackedEmptyFileTest");
            this.CreateEmptyFile();
            this.ValidateGitCommand("status");
            this.ValidateGitCommand("add .");
            this.RunGitCommand("commit -m \"Add new file\"");
            this.ValidateGitCommand("status");
        }

        [TestCase]
        public void CheckoutNewBranchTest()
        {
            this.ValidateGitCommand("checkout -b tests/functional/CheckoutNewBranchTest");
            this.ValidateGitCommand("status");
        }

        [TestCase]
        public void CreateFileSwitchBranchTest()
        {
            this.SwitchBranch(fileSystemAction: this.CreateFile);
        }

        [TestCase]
        public void CreateFileStageChangesSwitchBranchTest()
        {
            this.StageChangesSwitchBranch(fileSystemAction: this.CreateFile);
        }

        [TestCase]
        public void CreateFileCommitChangesSwitchBranchTest()
        {
            this.CommitChangesSwitchBranch(fileSystemAction: this.CreateFile);
        }

        [TestCase]
        public void CreateFileCommitChangesSwitchBranchSwitchBranchBackTest()
        {
            this.CommitChangesSwitchBranchSwitchBack(fileSystemAction: this.CreateFile);
        }

        [TestCase]
        public void DeleteFileSwitchBranchTest()
        {
            this.SwitchBranch(fileSystemAction: this.DeleteFile);
        }

        [TestCase]
        public void DeleteFileStageChangesSwitchBranchTest()
        {
            this.StageChangesSwitchBranch(fileSystemAction: this.DeleteFile);
        }

        [TestCase]
        public void DeleteFileCommitChangesSwitchBranchTest()
        {
            this.CommitChangesSwitchBranch(fileSystemAction: this.DeleteFile);
        }

        [TestCase]
        public void DeleteFileCommitChangesSwitchBranchSwitchBackTest()
        {
            this.CommitChangesSwitchBranchSwitchBack(fileSystemAction: this.DeleteFile);
        }

        [TestCase]
        public void DeleteFileCommitChangesSwitchBranchSwitchBackDeleteFolderTest()
        {
            // 663045 - Confirm that folder can be deleted after deleting file then changing
            // branches
            string deleteFolderPath = @"GVFS\GVFS\CommandLine";
            string deleteFilePath = deleteFolderPath + @"\CloneHelper.cs";

            this.CommitChangesSwitchBranchSwitchBack(fileSystemAction: () => this.DeleteFile(deleteFilePath));
            this.DeleteFolder(deleteFolderPath);
        }

        [TestCase]
        public void AddFileAndCommitOnNewBranchSwitchDeleteFolderAndSwitchBack()
        {
            // 663045 - Confirm that folder can be deleted after adding a file then changing
            // branches
            string newFileParentFolderPath = @"GVFS\GVFS\CommandLine";
            string newFilePath = newFileParentFolderPath + @"\testfile.txt";
            string newFileContents = "test contents";

            this.CommitChangesSwitchBranch(
                fileSystemAction: () => this.CreateFile(newFilePath, newFileContents),
                test: "AddFileAndCommitOnNewBranchSwitchDeleteFolderAndSwitchBack");

            this.ValidateGitCommand("checkout " + this.ControlGitRepo.Commitish);
            this.DeleteFolder(newFileParentFolderPath);

            this.ValidateGitCommand("checkout " + this.ControlGitRepo.Commitish);
            this.ValidateGitCommand("checkout tests/functional/AddFileAndCommitOnNewBranchSwitchDeleteFolderAndSwitchBack");

            this.FolderShouldExist(newFileParentFolderPath);
            this.FileShouldHaveContents(newFilePath, newFileContents);
        }

        [TestCase]
        public void AddFileInSubfolderAndCommitOnNewBranchSwitchDeleteFolderAndSwitchBack()
        {
            // 663045 - Confirm that grandparent folder can be deleted after adding a (granchild) file
            // then changing branches
            string newFileGrandParentFolderPath = @"GVFS\GVFS\CommandLine";
            string newFilePath = newFileGrandParentFolderPath + @"\testfile.txt";
            string newFileContents = "test contents";

            this.CommitChangesSwitchBranch(
                fileSystemAction: () => this.CreateFile(newFilePath, newFileContents),
                test: "AddFileInSubfolderAndCommitOnNewBranchSwitchDeleteFolderAndSwitchBack");

            this.ValidateGitCommand("checkout " + this.ControlGitRepo.Commitish);
            this.DeleteFolder(newFileGrandParentFolderPath);

            this.ValidateGitCommand("checkout " + this.ControlGitRepo.Commitish);
            this.ValidateGitCommand("checkout tests/functional/AddFileInSubfolderAndCommitOnNewBranchSwitchDeleteFolderAndSwitchBack");

            this.FolderShouldExist(newFileGrandParentFolderPath);
            this.FileShouldHaveContents(newFilePath, newFileContents);
        }

        [TestCase]
        public void CaseOnlyRenameFileAndChangeBranches()
        {
            // 693190 - Confirm that file does not disappear after case-only rename and branch
            // changes
            string newBranchName = "tests/functional/CaseOnlyRenameFileAndChangeBranches";
            string oldFileName = "Readme.md";
            string newFileName = "README.md";

            this.ValidateGitCommand("checkout -b " + newBranchName);
            this.ValidateGitCommand("mv {0} {1}", oldFileName, newFileName);
            this.ValidateGitCommand("add .");
            this.RunGitCommand("commit -m \"Change for CaseOnlyRenameFileAndChangeBranches\"");
            this.ValidateGitCommand("checkout " + this.ControlGitRepo.Commitish);
            this.FileShouldHaveCaseMatchingName(newFileName, oldFileName);

            this.ValidateGitCommand("checkout " + newBranchName);
            this.FileShouldHaveCaseMatchingName(newFileName, newFileName);
        }

        [TestCase]
        public void DeleteFolderAndChangeBranchToFolderWithDifferentCase()
        {
            // 692765 - Recursive sparse-checkout entries for folders should be case insensitive when
            // changing branches

            string folderName = "GVFlt_MultiThreadTest";

            string sparseFile = Path.Combine(this.Enlistment.RepoRoot, @".git\info\sparse-checkout");
            sparseFile.ShouldBeAFile(this.fileSystem).WithContents().ShouldNotContain(folderName);

            this.FolderShouldHaveCaseMatchingName(folderName, "GVFlt_MultiThreadTest");
            this.DeleteFolder(folderName);

            // b5fd7d23706a18cff3e2b8225588d479f7e51138 is the commit prior to deleting GVFLT_MultiThreadTest 
            // and re-adding it as as GVFlt_MultiThreadTest
            this.ValidateGitCommand("checkout b5fd7d23706a18cff3e2b8225588d479f7e51138");
            this.FolderShouldHaveCaseMatchingName(folderName, "GVFLT_MultiThreadTest");

            // TODO 696642: Because GVFS can leave around empty enumerated folders, switch back to 
            // ControlGitRepo.Commitish so that the control repo has the same folders as GVFS when [TearDown]
            // Validation occurs.
            // If we do not switch back to ControlGitRepo.Commitish, the GVFS repo will have folders left from
            // the enumeration that occurs in [Setup] (and this will not match the control repo)
            this.ValidateGitCommand("checkout " + this.ControlGitRepo.Commitish);
        }

        [TestCase]
        public void EditFileSwitchBranchTest()
        {
            this.SwitchBranch(fileSystemAction: this.EditFile);
        }

        [TestCase]
        public void EditFileStageChangesSwitchBranchTest()
        {
            this.StageChangesSwitchBranch(fileSystemAction: this.EditFile);
        }

        [TestCase]
        public void EditFileCommitChangesSwitchBranchTest()
        {
            this.CommitChangesSwitchBranch(fileSystemAction: this.EditFile);
        }

        [TestCase]
        public void EditFileCommitChangesSwitchBranchSwitchBackTest()
        {
            this.CommitChangesSwitchBranchSwitchBack(fileSystemAction: this.EditFile);
        }

        [TestCase]
        public void RenameFileCommitChangesSwitchBranchSwitchBackTest()
        {
            this.CommitChangesSwitchBranchSwitchBack(fileSystemAction: this.RenameFile);
        }

        [TestCase]
        [Ignore("Disabled until moving partial folders is supported")]
        public void MoveFolderCommitChangesSwitchBranchSwitchBackTest()
        {
            this.CommitChangesSwitchBranchSwitchBack(fileSystemAction: this.MoveFolder);
        }

        [TestCase]
        public void AddFileCommitThenDeleteAndCommit()
        {
            this.ValidateGitCommand("checkout -b tests/functional/AddFileCommitThenDeleteAndCommit_before");
            this.ValidateGitCommand("checkout -b tests/functional/AddFileCommitThenDeleteAndCommit_after");
            string filePath = @"GVFS\testfile.txt";
            this.CreateFile(filePath, "Some new content for the file");
            this.ValidateGitCommand("status");
            this.ValidateGitCommand("add .");
            this.RunGitCommand("commit -m \"Change for AddFileCommitThenDeleteAndCommit\"");
            this.DeleteFile(filePath);
            this.ValidateGitCommand("status");
            this.ValidateGitCommand("add .");
            this.RunGitCommand("commit -m \"Delete file for AddFileCommitThenDeleteAndCommit\"");
            this.ValidateGitCommand("checkout tests/functional/AddFileCommitThenDeleteAndCommit_before");
            this.Enlistment.RepoRoot.ShouldBeADirectory(this.fileSystem)
               .WithDeepStructure(this.ControlGitRepo.RootPath);
            this.ValidateGitCommand("checkout tests/functional/AddFileCommitThenDeleteAndCommit_after");
        }

        [TestCase]
        public void AddFileCommitThenDeleteAndResetSoft()
        {
            this.ValidateGitCommand("checkout -b tests/functional/AddFileCommitThenDeleteAndResetSoft");
            string filePath = @"GVFS\testfile.txt";
            this.CreateFile(filePath, "Some new content for the file");
            this.ValidateGitCommand("status");
            this.ValidateGitCommand("add .");
            this.RunGitCommand("commit -m \"Change for AddFileCommitThenDeleteAndCommit\"");
            this.DeleteFile(filePath);
            this.ValidateGitCommand("status");
            this.ValidateGitCommand("reset --soft HEAD~1");
        }

        [TestCase]
        public void AddFileCommitThenDeleteAndResetMixed()
        {
            this.ValidateGitCommand("checkout -b tests/functional/AddFileCommitThenDeleteAndResetSoft");
            string filePath = @"GVFS\testfile.txt";
            this.CreateFile(filePath, "Some new content for the file");
            this.ValidateGitCommand("status");
            this.ValidateGitCommand("add .");
            this.RunGitCommand("commit -m \"Change for AddFileCommitThenDeleteAndCommit\"");
            this.DeleteFile(filePath);
            this.ValidateGitCommand("status");
            this.ValidateGitCommand("reset --soft HEAD~1");
        }

        [TestCase]
        public void AddFolderAndFileCommitThenDeleteAndResetSoft()
        {
            this.ValidateGitCommand("checkout -b tests/functional/AddFileCommitThenDeleteAndResetSoft");
            string folderPath = "test_folder";
            this.CreateFolder(folderPath);
            string filePath = folderPath + @"\testfile.txt";
            this.CreateFile(filePath, "Some new content for the file");
            this.ValidateGitCommand("status");
            this.ValidateGitCommand("add .");
            this.RunGitCommand("commit -m \"Change for AddFileCommitThenDeleteAndCommit\"");
            this.DeleteFile(filePath);
            this.DeleteFolder(folderPath);
            this.ValidateGitCommand("status");
            this.ValidateGitCommand("reset --soft HEAD~1");
        }

        [TestCase]
        public void AddFolderAndFileCommitThenDeleteAndResetMixed()
        {
            this.ValidateGitCommand("checkout -b tests/functional/AddFileCommitThenDeleteAndResetSoft");
            string folderPath = "test_folder";
            this.CreateFolder(folderPath);
            string filePath = folderPath + @"\testfile.txt";
            this.CreateFile(filePath, "Some new content for the file");
            this.ValidateGitCommand("status");
            this.ValidateGitCommand("add .");
            this.RunGitCommand("commit -m \"Change for AddFileCommitThenDeleteAndCommit\"");
            this.DeleteFile(filePath);
            this.DeleteFolder(folderPath);
            this.ValidateGitCommand("status");
            this.ValidateGitCommand("reset --mixed HEAD~1");
        }

        [TestCase]
        public void AddFolderAndFileCommitThenResetSoftAndResetHard()
        {
            this.ValidateGitCommand("checkout -b tests/functional/AddFileCommitThenDeleteAndResetSoft");
            string folderPath = "test_folder";
            this.CreateFolder(folderPath);
            string filePath = folderPath + @"\testfile.txt";
            this.CreateFile(filePath, "Some new content for the file");
            this.ValidateGitCommand("status");
            this.ValidateGitCommand("add .");
            this.RunGitCommand("commit -m \"Change for AddFileCommitThenDeleteAndCommit\"");
            this.ValidateGitCommand("status");
            this.ValidateGitCommand("reset --soft HEAD~1");
            this.ValidateGitCommand("reset --hard HEAD");
        }

        [TestCase]
        public void AddFolderAndFileCommitThenResetSoftAndResetMixed()
        {
            this.ValidateGitCommand("checkout -b tests/functional/AddFileCommitThenDeleteAndResetSoft");
            string folderPath = "test_folder";
            this.CreateFolder(folderPath);
            string filePath = folderPath + @"\testfile.txt";
            this.CreateFile(filePath, "Some new content for the file");
            this.ValidateGitCommand("status");
            this.ValidateGitCommand("add .");
            this.RunGitCommand("commit -m \"Change for AddFileCommitThenDeleteAndCommit\"");
            this.ValidateGitCommand("status");
            this.ValidateGitCommand("reset --soft HEAD~1");
            this.ValidateGitCommand("reset --mixed HEAD");
        }

        [TestCase]
        public void AddFoldersAndFilesAndRenameFolder()
        {
            this.ValidateGitCommand("checkout -b tests/functional/AddFoldersAndFilesAndRenameFolder");

            string topMostNewFolder = "AddFoldersAndFilesAndRenameFolder_Test";
            this.CreateFolder(topMostNewFolder);
            this.CreateFile(topMostNewFolder + @"\top_level_test_file.txt", "test contents");

            string testFolderLevel1 = topMostNewFolder + @"\TestFolderLevel1";
            this.CreateFolder(testFolderLevel1);
            this.CreateFile(testFolderLevel1 + @"\level_1_test_file.txt", "test contents");

            string testFolderLevel2 = testFolderLevel1 + @"\TestFolderLevel2";
            this.CreateFolder(testFolderLevel2);
            this.CreateFile(testFolderLevel2 + @"\level_2_test_file.txt", "test contents");

            string testFolderLevel3 = testFolderLevel2 + @"\TestFolderLevel3";
            this.CreateFolder(testFolderLevel3);
            this.CreateFile(testFolderLevel3 + @"\level_3_test_file.txt", "test contents");
            this.ValidateGitCommand("status");

            this.MoveFolder(testFolderLevel3, testFolderLevel2 + @"\TestFolderLevel3Renamed");
            this.ValidateGitCommand("status");

            this.MoveFolder(testFolderLevel2, testFolderLevel1 + @"\TestFolderLevel2Renamed");
            this.ValidateGitCommand("status");

            this.MoveFolder(testFolderLevel1, topMostNewFolder + @"\TestFolderLevel1Renamed");
            this.ValidateGitCommand("status");

            this.MoveFolder(topMostNewFolder, "AddFoldersAndFilesAndRenameFolder_TestRenamed");
            this.ValidateGitCommand("status");
        }

        [TestCase]
        public void AddFileAfterFolderRename()
        {
            this.ValidateGitCommand("checkout -b tests/functional/AddFileAfterFolderRename");

            string folder = "AddFileAfterFolderRename_Test";
            string renamedFolder = "AddFileAfterFolderRename_TestRenamed";
            this.CreateFolder(folder);
            this.MoveFolder(folder, renamedFolder);
            this.CreateFile(renamedFolder + @"\test_file.txt", "test contents");
            this.ValidateGitCommand("status");
        }

        [TestCase]
        public void ResetSoft()
        {
            this.ValidateGitCommand("checkout -b tests/functional/ResetSoft");
            this.ValidateGitCommand("reset --soft HEAD~1");
        }

        [TestCase]
        public void ResetMixed()
        {
            this.ValidateGitCommand("checkout -b tests/functional/ResetMixed");
            this.ValidateGitCommand("reset --mixed HEAD~1");
        }

        [TestCase]
        public void ResetMixed2()
        {
            this.ValidateGitCommand("checkout -b tests/functional/ResetMixed2");
            this.ValidateGitCommand("reset HEAD~1");
        }

        [TestCase]
        public void ManuallyModifyHead()
        {
            this.ValidateGitCommand("status");
            this.ReplaceText(TestConstants.DotGit.Head, "f1bce402a7a980a8320f3f235cf8c8fdade4b17a");
            this.ValidateGitCommand("status");
        }

        [TestCase]
        [Ignore("TODO 690810 - Invesigate why this test is failing")]
        public void ResetSoftTwice()
        {
            this.ValidateGitCommand("checkout -b tests/functional/ResetSoftTwice");

            // A folder rename occured between 99fc72275f950b0052c8548bbcf83a851f2b4467 and 
            // the subsequent commit 60d19c87328120d11618ad563c396044a50985b2
            this.ValidateGitCommand("reset --soft 60d19c87328120d11618ad563c396044a50985b2");
            this.ValidateGitCommand("reset --soft 99fc72275f950b0052c8548bbcf83a851f2b4467");
        }

        [TestCase]
        [Ignore("TODO 690810 - Invesigate why this test is failing")]
        public void ResetMixedTwice()
        {
            this.ValidateGitCommand("checkout -b tests/functional/ResetMixedTwice");

            // A folder rename occured between 99fc72275f950b0052c8548bbcf83a851f2b4467 and 
            // the subsequent commit 60d19c87328120d11618ad563c396044a50985b2
            this.ValidateGitCommand("reset --mixed 60d19c87328120d11618ad563c396044a50985b2");
            this.ValidateGitCommand("reset --mixed 99fc72275f950b0052c8548bbcf83a851f2b4467");
        }

        [TestCase]
        [Ignore("TODO 690810 - Invesigate why this test is failing")]
        public void ResetMixed2Twice()
        {
            this.ValidateGitCommand("checkout -b tests/functional/ResetMixed2Twice");

            // A folder rename occured between 99fc72275f950b0052c8548bbcf83a851f2b4467 and 
            // the subsequent commit 60d19c87328120d11618ad563c396044a50985b2
            this.ValidateGitCommand("reset 60d19c87328120d11618ad563c396044a50985b2");
            this.ValidateGitCommand("reset 99fc72275f950b0052c8548bbcf83a851f2b4467");
        }

        [TestCase]
        public void ResetHardAfterCreate()
        {
            this.ValidateGitCommand("checkout -b tests/functional/ResetHardAfterCreate");
            this.CreateFile();
            this.ValidateGitCommand("status");
            this.ValidateGitCommand("reset --hard HEAD");
        }

        [TestCase]
        public void ResetHardAfterEdit()
        {
            this.ValidateGitCommand("checkout -b tests/functional/ResetHardAfterEdit");
            this.EditFile();
            this.ValidateGitCommand("status");
            this.ValidateGitCommand("reset --hard HEAD");
        }

        [TestCase]
        public void ResetHardAfterDelete()
        {
            this.ValidateGitCommand("checkout -b tests/functional/ResetHardAfterDelete");
            this.DeleteFile();
            this.ValidateGitCommand("status");
            this.ValidateGitCommand("reset --hard HEAD");
        }

        [TestCase]
        public void ResetHardAfterCreateAndAdd()
        {
            this.ValidateGitCommand("checkout -b tests/functional/ResetHardAfterCreateAndAdd");
            this.CreateFile();
            this.ValidateGitCommand("status");
            this.ValidateGitCommand("add .");
            this.ValidateGitCommand("reset --hard HEAD");
        }

        [TestCase]
        public void ResetHardAfterEditAndAdd()
        {
            this.ValidateGitCommand("checkout -b tests/functional/ResetHardAfterEditAndAdd");
            this.EditFile();
            this.ValidateGitCommand("status");
            this.ValidateGitCommand("add .");
            this.ValidateGitCommand("reset --hard HEAD");
        }

        [TestCase]
        public void ResetHardAfterDeleteAndAdd()
        {
            this.ValidateGitCommand("checkout -b tests/functional/ResetHardAfterDeleteAndAdd");
            this.DeleteFile();
            this.ValidateGitCommand("status");
            this.ValidateGitCommand("add .");
            this.ValidateGitCommand("reset --hard HEAD");
        }

        [TestCase]
        public void ChangeTwoBranchesAndMerge()
        {
            this.ValidateGitCommand("checkout -b tests/functional/ChangeTwoBranchesAndMerge_1");
            this.EditFile();
            this.ValidateGitCommand("status");
            this.ValidateGitCommand("add .");
            this.RunGitCommand("commit -m \"Change for ChangeTwoBranchesAndMerge first branch\"");

            this.ValidateGitCommand("checkout " + this.ControlGitRepo.Commitish);
            this.ValidateGitCommand("checkout -b tests/functional/ChangeTwoBranchesAndMerge_2");
            this.DeleteFile();
            this.ValidateGitCommand("status");
            this.ValidateGitCommand("add .");
            this.RunGitCommand("commit -m \"Change for ChangeTwoBranchesAndMerge second branch\"");
            this.ValidateGitCommand("merge tests/functional/ChangeTwoBranchesAndMerge_1");
        }

        [TestCase]
        public void ChangeBranchAndCherryPickIntoAnotherBranch()
        {
            this.ValidateGitCommand("checkout -b tests/functional/ChangeBranchesAndCherryPickIntoAnotherBranch_1");
            this.CreateFile();
            this.ValidateGitCommand("status");
            this.ValidateGitCommand("add .");
            this.RunGitCommand("commit -m \"Create for ChangeBranchesAndCherryPickIntoAnotherBranch first branch\"");
            this.DeleteFile();
            this.ValidateGitCommand("status");
            this.ValidateGitCommand("add .");
            this.RunGitCommand("commit -m \"Delete for ChangeBranchesAndCherryPickIntoAnotherBranch first branch\"");
            this.ValidateGitCommand("tag DeleteForCherryPick");
            this.EditFile();
            this.ValidateGitCommand("status");
            this.ValidateGitCommand("add .");
            this.RunGitCommand("commit -m \"Edit for ChangeBranchesAndCherryPickIntoAnotherBranch first branch\"");

            this.ValidateGitCommand("checkout " + this.ControlGitRepo.Commitish);
            this.ValidateGitCommand("checkout -b tests/functional/ChangeBranchesAndCherryPickIntoAnotherBranch_2");
            this.RunGitCommand("cherry-pick DeleteForCherryPick");
        }

        [TestCase]
        public void ChangeBranchAndMergeRebaseOnAnotherBranch()
        {
            this.ValidateGitCommand("checkout -b tests/functional/ChangeBranchAndMergeRebaseOnAnotherBranch_1");
            this.CreateFile();
            this.ValidateGitCommand("status");
            this.ValidateGitCommand("add .");
            this.RunGitCommand("commit -m \"Create for ChangeBranchAndMergeRebaseOnAnotherBranch first branch\"");
            this.DeleteFile();
            this.ValidateGitCommand("status");
            this.ValidateGitCommand("add .");
            this.RunGitCommand("commit -m \"Delete for ChangeBranchAndMergeRebaseOnAnotherBranch first branch\"");

            this.ValidateGitCommand("checkout " + this.ControlGitRepo.Commitish);
            this.ValidateGitCommand("checkout -b tests/functional/ChangeBranchAndMergeRebaseOnAnotherBranch_2");
            this.EditFile();
            this.ValidateGitCommand("status");
            this.ValidateGitCommand("add .");
            this.RunGitCommand("commit -m \"Edit for ChangeBranchAndMergeRebaseOnAnotherBranch first branch\"");

            this.RunGitCommand("rebase --merge tests/functional/ChangeBranchAndMergeRebaseOnAnotherBranch_1");
        }

        [TestCase]
        public void ChangeBranchAndRebaseOnAnotherBranch()
        {
            this.ValidateGitCommand("checkout -b tests/functional/ChangeBranchAndRebaseOnAnotherBranch_1");
            this.CreateFile();
            this.ValidateGitCommand("status");
            this.ValidateGitCommand("add .");
            this.RunGitCommand("commit -m \"Create for ChangeBranchAndRebaseOnAnotherBranch first branch\"");
            this.DeleteFile();
            this.ValidateGitCommand("status");
            this.ValidateGitCommand("add .");
            this.RunGitCommand("commit -m \"Delete for ChangeBranchAndRebaseOnAnotherBranch first branch\"");

            this.ValidateGitCommand("checkout " + this.ControlGitRepo.Commitish);
            this.ValidateGitCommand("checkout -b tests/functional/ChangeBranchAndRebaseOnAnotherBranch_2");
            this.EditFile();
            this.ValidateGitCommand("status");
            this.ValidateGitCommand("add .");
            this.RunGitCommand("commit -m \"Edit for ChangeBranchAndRebaseOnAnotherBranch first branch\"");

            this.ValidateGitCommand("rebase tests/functional/ChangeBranchAndRebaseOnAnotherBranch_1");
        }

        [TestCase]
        public void StashChanges()
        {
            this.ValidateGitCommand("checkout -b tests/functional/StashChanges");
            this.EditFile();
            this.ValidateGitCommand("status");
            this.ValidateGitCommand("add .");
            this.ValidateGitCommand("stash");

            this.ValidateGitCommand("checkout " + this.ControlGitRepo.Commitish);
            this.ValidateGitCommand("checkout -b tests/functional/StashChanges_2");
            this.RunGitCommand("stash pop");
        }

        [TestCase]
        public void OpenFileThenCheckout()
        {
            string virtualFile = Path.Combine(this.Enlistment.RepoRoot, GitCommandsTests.EditFilePath);
            string controlFile = Path.Combine(this.ControlGitRepo.RootPath, GitCommandsTests.EditFilePath);

            // Open files with ReadWrite sharing because depending on the state of the index (and the mtimes), git might need to read the file
            // as part of status (while we have the handle open).
            using (FileStream virtualFS = File.Open(virtualFile, FileMode.OpenOrCreate, FileAccess.Write, FileShare.ReadWrite))
            using (StreamWriter virtualWriter = new StreamWriter(virtualFS))
            using (FileStream controlFS = File.Open(controlFile, FileMode.OpenOrCreate, FileAccess.Write, FileShare.ReadWrite))
            using (StreamWriter controlWriter = new StreamWriter(controlFS))
            {
                this.ValidateGitCommand("checkout -b tests/functional/OpenFileThenCheckout");
                virtualWriter.WriteLine("// Adding a line for testing purposes");
                controlWriter.WriteLine("// Adding a line for testing purposes");
                this.ValidateGitCommand("status");
            }

            // NOTE: Due to optimizations in checkout -b, the modified files will not be included as part of the
            // success message.  Validate that the succcess messages match, and the call to validate "status" below
            // will ensure that GVFS is still reporting the edited file as modified.

            string controlRepoRoot = this.ControlGitRepo.RootPath;
            string gvfsRepoRoot = this.Enlistment.RepoRoot;
            string command = "checkout -b tests/functional/OpenFileThenCheckout_2";
            ProcessResult expectedResult = GitProcess.InvokeProcess(controlRepoRoot, command);
            ProcessResult actualResult = GitProcess.InvokeProcess(gvfsRepoRoot, command);
            actualResult.Errors.ShouldEqual(expectedResult.Errors);
            actualResult.Errors.ShouldContain("Switched to a new branch");

            this.ValidateGitCommand("status");
        }

        [TestCase]
        public void EditFileNeedingUtf8Encoding()
        {
            this.ValidateGitCommand("checkout -b tests/functional/EditFileNeedingUtf8Encoding");
            this.ValidateGitCommand("status");
            string virtualFile = Path.Combine(this.Enlistment.RepoRoot, EncodingFileFolder, EncodingFilename);
            string controlFile = Path.Combine(this.ControlGitRepo.RootPath, EncodingFileFolder, EncodingFilename);

            string contents = virtualFile.ShouldBeAFile(this.fileSystem).WithContents();
            string expectedContents = controlFile.ShouldBeAFile(this.fileSystem).WithContents();
            contents.ShouldEqual(expectedContents);

            // Check that the entry in the sparse-checkout matches
            string sparseCheckoutFile = Path.Combine(this.Enlistment.RepoRoot, TestConstants.DotGit.Info.SparseCheckout);
            sparseCheckoutFile.ShouldBeAFile(this.fileSystem).WithContents().ShouldContain(EncodingFilename);
            this.ValidateGitCommand("status");

            this.AppendAllText(virtualFile, ContentWhenEditingFile);
            this.AppendAllText(controlFile, ContentWhenEditingFile);
            this.ValidateGitCommand("status");
        }

        [TestCase]
        public void UseAlias()
        {
            this.ValidateGitCommand("config --local alias.potato status");
            this.ValidateGitCommand("potato");
        }

        private void SwitchBranch(Action fileSystemAction, [CallerMemberName]string test = GitCommandsTests.UnknownTestName)
        {
            this.ValidateGitCommand("checkout -b tests/functional/{0}", test);
            fileSystemAction();
            this.ValidateGitCommand("status");
        }

        private void StageChangesSwitchBranch(Action fileSystemAction, [CallerMemberName]string test = GitCommandsTests.UnknownTestName)
        {
            this.ValidateGitCommand("checkout -b tests/functional/{0}", test);
            fileSystemAction();
            this.ValidateGitCommand("status");
            this.ValidateGitCommand("add .");
        }

        private void CommitChangesSwitchBranch(Action fileSystemAction, [CallerMemberName]string test = GitCommandsTests.UnknownTestName)
        {
            this.ValidateGitCommand("checkout -b tests/functional/{0}", test);
            fileSystemAction();
            this.ValidateGitCommand("status");
            this.ValidateGitCommand("add .");
            this.RunGitCommand("commit -m \"Change for {0}\"", test);
        }

        private void CommitChangesSwitchBranchSwitchBack(Action fileSystemAction, [CallerMemberName]string test = GitCommandsTests.UnknownTestName)
        {
            string branch = string.Format("tests/functional/{0}", test);
            this.ValidateGitCommand("checkout -b {0}", branch);
            fileSystemAction();
            this.ValidateGitCommand("status");
            this.ValidateGitCommand("add .");
            this.RunGitCommand("commit -m \"Change for {0}\"", branch);
            this.ValidateGitCommand("checkout " + this.ControlGitRepo.Commitish);
            this.Enlistment.RepoRoot.ShouldBeADirectory(this.fileSystem)
                .WithDeepStructure(this.ControlGitRepo.RootPath);

            this.ValidateGitCommand("checkout {0}", branch);
        }

        private void CheckHeadCommitTree()
        {
            this.ValidateGitCommand("ls-tree HEAD");
        }

        // Some commands compute a new commit sha, which is dependent on time and therefore
        // won't match what is in the control repo.  For those commands, we just ensure that
        // the errors match what we expect, but we skip comparing the output
        private void RunGitCommand(string command, params object[] args)
        {
            string controlRepoRoot = this.ControlGitRepo.RootPath;
            string gvfsRepoRoot = this.Enlistment.RepoRoot;
            command = string.Format(command, args);

            ProcessResult expectedResult = GitProcess.InvokeProcess(controlRepoRoot, command);
            ProcessResult actualResult = GitHelpers.InvokeGitAgainstGVFSRepo(gvfsRepoRoot, command);
            actualResult.Errors.ShouldEqual(expectedResult.Errors);

            if (command != "status")
            {
                this.ValidateGitCommand("status");
            }
        }

        // Ensure that errors match when running git commands.  However, if the actual errors are just
        // "Checking out files:" lines, those lines will be ignored
        // TODO 881663: Determine why reset --hard HEAD sometimes produces "Checking out files:" output
        private void RunGitCommandNoProgress(string command, params object[] args)
        {
            string controlRepoRoot = this.ControlGitRepo.RootPath;
            string gvfsRepoRoot = this.Enlistment.RepoRoot;
            command = string.Format(command, args);

            ProcessResult expectedResult = GitProcess.InvokeProcess(controlRepoRoot, command);
            ProcessResult actualResult = GitHelpers.InvokeGitAgainstGVFSRepo(gvfsRepoRoot, command);

            if (expectedResult.Errors.Length > 0)
            {
                actualResult.Errors.ShouldEqual(expectedResult.Errors);
            }
            else if (actualResult.Errors.Length > 0)
            {
                foreach (string errorLine in actualResult.Errors.Split(new[] { '\r', '\n' }, StringSplitOptions.RemoveEmptyEntries))
                {
                    errorLine.ShouldContain("Checking out files:");
                }
            }

            if (command != "status")
            {
                this.ValidateGitCommand("status");
            }
        }

        private void ValidateGitCommand(string command, params object[] args)
        {
            GitHelpers.ValidateGitCommand(
                this.Enlistment,
                this.ControlGitRepo,
                command,
                args);
        }

        private void CreateFile()
        {
            this.CreateFile("tempFile.txt", "Some content here");
        }

        private void CreateEmptyFile()
        {
            string filePath = "emptyFile.txt";
            string virtualFile = Path.Combine(this.Enlistment.RepoRoot, filePath);
            string controlFile = Path.Combine(this.ControlGitRepo.RootPath, filePath);
            this.fileSystem.CreateEmptyFile(virtualFile);
            this.fileSystem.CreateEmptyFile(controlFile);
        }

        private void CreateFile(string filePath, string content)
        {
            string virtualFile = Path.Combine(this.Enlistment.RepoRoot, filePath);
            string controlFile = Path.Combine(this.ControlGitRepo.RootPath, filePath);
            this.fileSystem.WriteAllText(virtualFile, content);
            this.fileSystem.WriteAllText(controlFile, content);
        }

        private void CreateFolder(string folderPath)
        {
            string virtualFolder = Path.Combine(this.Enlistment.RepoRoot, folderPath);
            string controlFolder = Path.Combine(this.ControlGitRepo.RootPath, folderPath);
            this.fileSystem.CreateDirectory(virtualFolder);
            this.fileSystem.CreateDirectory(controlFolder);
        }

        private void EditFile()
        {
            this.AppendAllText(GitCommandsTests.EditFilePath, ContentWhenEditingFile);
        }

        private void AppendAllText(string filePath, string content)
        {
            string virtualFile = Path.Combine(this.Enlistment.RepoRoot, filePath);
            string controlFile = Path.Combine(this.ControlGitRepo.RootPath, filePath);
            this.fileSystem.AppendAllText(virtualFile, content);
            this.fileSystem.AppendAllText(controlFile, content);
        }

        private void ReplaceText(string filePath, string newContent)
        {
            string virtualFile = Path.Combine(this.Enlistment.RepoRoot, filePath);
            string controlFile = Path.Combine(this.ControlGitRepo.RootPath, filePath);
            this.fileSystem.WriteAllText(virtualFile, newContent);
            this.fileSystem.WriteAllText(controlFile, newContent);
        }

        private void DeleteFile()
        {
            this.DeleteFile(GitCommandsTests.DeleteFilePath);
        }

        private void DeleteFile(string filePath)
        {
            string virtualFile = Path.Combine(this.Enlistment.RepoRoot, filePath);
            string controlFile = Path.Combine(this.ControlGitRepo.RootPath, filePath);
            this.fileSystem.DeleteFile(virtualFile);
            this.fileSystem.DeleteFile(controlFile);
            virtualFile.ShouldNotExistOnDisk(this.fileSystem);
            controlFile.ShouldNotExistOnDisk(this.fileSystem);
        }

        private void DeleteFolder(string folderPath)
        {
            string virtualFolder = Path.Combine(this.Enlistment.RepoRoot, folderPath);
            string controlFolder = Path.Combine(this.ControlGitRepo.RootPath, folderPath);
            this.fileSystem.DeleteDirectory(virtualFolder);
            this.fileSystem.DeleteDirectory(controlFolder);
            virtualFolder.ShouldNotExistOnDisk(this.fileSystem);
            controlFolder.ShouldNotExistOnDisk(this.fileSystem);
        }

        private void RenameFile()
        {
            string virtualFileFrom = Path.Combine(this.Enlistment.RepoRoot, GitCommandsTests.RenameFilePathFrom);
            string virtualFileTo = Path.Combine(this.Enlistment.RepoRoot, GitCommandsTests.RenameFilePathTo);
            string controlFileFrom = Path.Combine(this.ControlGitRepo.RootPath, GitCommandsTests.RenameFilePathFrom);
            string controlFileTo = Path.Combine(this.ControlGitRepo.RootPath, GitCommandsTests.RenameFilePathTo);
            this.fileSystem.MoveFile(virtualFileFrom, virtualFileTo);
            this.fileSystem.MoveFile(controlFileFrom, controlFileTo);
            virtualFileFrom.ShouldNotExistOnDisk(this.fileSystem);
            controlFileFrom.ShouldNotExistOnDisk(this.fileSystem);
        }

        private void MoveFolder()
        {
            this.MoveFolder(GitCommandsTests.RenameFolderPathFrom, GitCommandsTests.RenameFolderPathTo);
        }

        private void MoveFolder(string pathFrom, string pathTo)
        {
            string virtualFileFrom = Path.Combine(this.Enlistment.RepoRoot, pathFrom);
            string virtualFileTo = Path.Combine(this.Enlistment.RepoRoot, pathTo);
            string controlFileFrom = Path.Combine(this.ControlGitRepo.RootPath, pathFrom);
            string controlFileTo = Path.Combine(this.ControlGitRepo.RootPath, pathTo);
            this.fileSystem.MoveDirectory(virtualFileFrom, virtualFileTo);
            this.fileSystem.MoveDirectory(controlFileFrom, controlFileTo);
            virtualFileFrom.ShouldNotExistOnDisk(this.fileSystem);
            controlFileFrom.ShouldNotExistOnDisk(this.fileSystem);
        }

        private void FolderShouldExist(string folderPath)
        {
            string virtualFolder = Path.Combine(this.Enlistment.RepoRoot, folderPath);
            string controlFolder = Path.Combine(this.ControlGitRepo.RootPath, folderPath);
            virtualFolder.ShouldBeADirectory(this.fileSystem);
            controlFolder.ShouldBeADirectory(this.fileSystem);
        }

        private void ShouldNotExistOnDisk(string path)
        {
            string virtualPath = Path.Combine(this.Enlistment.RepoRoot, path);
            string controlPath = Path.Combine(this.ControlGitRepo.RootPath, path);
            virtualPath.ShouldNotExistOnDisk(this.fileSystem);
            controlPath.ShouldNotExistOnDisk(this.fileSystem);
        }

        private void FileShouldHaveContents(string filePath, string contents)
        {
            string virtualFilePath = Path.Combine(this.Enlistment.RepoRoot, filePath);
            string controlFilePath = Path.Combine(this.ControlGitRepo.RootPath, filePath);
            virtualFilePath.ShouldBeAFile(this.fileSystem).WithContents(contents);
            controlFilePath.ShouldBeAFile(this.fileSystem).WithContents(contents);
        }

        private void FileShouldHaveCaseMatchingName(string filePath, string caseSensitiveName)
        {
            string virtualFilePath = Path.Combine(this.Enlistment.RepoRoot, filePath);
            string controlFilePath = Path.Combine(this.ControlGitRepo.RootPath, filePath);            
            virtualFilePath.ShouldBeAFile(this.fileSystem).WithCaseMatchingName(caseSensitiveName);
            controlFilePath.ShouldBeAFile(this.fileSystem).WithCaseMatchingName(caseSensitiveName);
        }

        private void FolderShouldHaveCaseMatchingName(string folderPath, string caseSensitiveName)
        {
            string virtualFolderPath = Path.Combine(this.Enlistment.RepoRoot, folderPath);
            string controlFolderPath = Path.Combine(this.ControlGitRepo.RootPath, folderPath);
            virtualFolderPath.ShouldBeADirectory(this.fileSystem).WithCaseMatchingName(caseSensitiveName);
            controlFolderPath.ShouldBeADirectory(this.fileSystem).WithCaseMatchingName(caseSensitiveName);
        }
    }
}
