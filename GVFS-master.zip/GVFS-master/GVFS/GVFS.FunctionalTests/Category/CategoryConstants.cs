﻿namespace GVFS.FunctionalTests.Category
{
    public static class CategoryConstants
    {
        public const string FastFetch = "FastFetch";
    }
}
