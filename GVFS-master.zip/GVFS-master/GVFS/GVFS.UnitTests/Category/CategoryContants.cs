﻿namespace GVFS.UnitTests.Category
{
    public static class CategoryContants
    {
        public const string ExceptionExpected = "ExceptionExpected";
    }
}
