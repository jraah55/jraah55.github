﻿using System;

namespace GVFS.Common.Git
{
    public class CatFileTimeoutException : TimeoutException
    {
    }
}
