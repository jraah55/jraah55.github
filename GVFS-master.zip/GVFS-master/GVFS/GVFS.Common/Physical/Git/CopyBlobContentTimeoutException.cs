﻿using System;

namespace GVFS.Common.Physical.Git
{
    public class CopyBlobContentTimeoutException : TimeoutException
    {
    }
}
