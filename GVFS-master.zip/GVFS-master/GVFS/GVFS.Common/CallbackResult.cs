﻿namespace GVFS.Common
{
    public enum CallbackResult
    {
        Success,
        RetryableError,
        FatalError
    }
}
