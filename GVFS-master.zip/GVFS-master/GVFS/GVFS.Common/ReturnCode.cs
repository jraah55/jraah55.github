﻿namespace GVFS.Common
{
    public enum ReturnCode
    {
        Success = 0,       
        RebootRequired = 2,
        GenericError = 3
    }
}
