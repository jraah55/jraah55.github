#pragma once

extern "C"
{
    NATIVE_TESTS_EXPORT bool PlaceHolderHasVersionInfo(const char* virtualPath, int version, const WCHAR* sha, const WCHAR* commit);
}