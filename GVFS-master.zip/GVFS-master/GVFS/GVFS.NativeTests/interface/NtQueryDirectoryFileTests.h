#pragma once

extern "C"
{
    NATIVE_TESTS_EXPORT bool QueryDirectoryFileRestartScanResetsFilter(const char* folderPath);
}
