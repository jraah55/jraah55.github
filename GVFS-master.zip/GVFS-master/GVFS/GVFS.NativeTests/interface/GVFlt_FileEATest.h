#pragma once

extern "C"
{
	NATIVE_TESTS_EXPORT bool GVFlt_OneEAAttributeWillPass(const char* virtualRootPath);
}
