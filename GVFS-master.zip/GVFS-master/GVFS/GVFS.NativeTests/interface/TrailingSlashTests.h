
#pragma once

extern "C"
{
    NATIVE_TESTS_EXPORT bool EnumerateWithTrailingSlashMatchesWithoutSlashAfterDelete(const char* virtualRootPath);
}