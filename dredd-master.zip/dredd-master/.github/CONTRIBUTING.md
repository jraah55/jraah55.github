# Contributing Guidelines

...are [in documentation](https://dredd.readthedocs.io/en/latest/contributing/) 📚
