
#### :rocket: Why this change?

#### :memo: Related issues and Pull Requests

#### :white_check_mark: What didn't I forget?

- [ ] To write docs
- [ ] To write tests
- [ ] To put [Conventional Changelog](https://dredd.readthedocs.io/en/latest/contributing/#sem-rel) prefixes in front of all my commits and run `npm run lint`
